<?php
// Heading
$_['heading_title'] = 'Total Sellers Sales';

// Text
$_['text_view']     = 'View more...';
