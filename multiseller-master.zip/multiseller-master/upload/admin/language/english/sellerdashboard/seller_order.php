<?php
// Heading
$_['heading_title'] = 'Total Sellers Orders';

// Text
$_['text_view']     = 'View more...';
