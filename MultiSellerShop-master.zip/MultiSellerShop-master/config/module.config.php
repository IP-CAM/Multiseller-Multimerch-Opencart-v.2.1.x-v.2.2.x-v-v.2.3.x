<?php

return array(
    'controllers' => array(
        'invokables' => array(
            'MultiSellerShop\Controller\Category' => 'MultiSellerShop\Controller\CategoryController',
            'MultiSellerShop\Controller\Product' => 'MultiSellerShop\Controller\ProductController'
        ),
    ),
    
    
);
