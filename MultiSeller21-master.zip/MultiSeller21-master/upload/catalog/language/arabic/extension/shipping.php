<?php
// Heading
$_['heading_title']     = 'طرق الشحن';

// Text
$_['text_success']      = 'تم التعديل !';
$_['text_list']         = 'قائمة';
$_['text_disabled']         = 'معطل';
$_['text_enabled']         = 'مفعل';

// Column
$_['column_name']       = 'طريقة الشحن';
$_['column_shipping_name']       = 'اسم الشحن';
$_['column_status']     = 'الحالة';
$_['column_sort_order'] = 'ترتيب الفرز';
$_['column_action']     = 'تحرير';
