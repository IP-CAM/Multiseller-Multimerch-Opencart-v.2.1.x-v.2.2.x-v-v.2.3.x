<?php
$_['heading_title'] = '<b>Redhut MultiSeller</b>';
?>
