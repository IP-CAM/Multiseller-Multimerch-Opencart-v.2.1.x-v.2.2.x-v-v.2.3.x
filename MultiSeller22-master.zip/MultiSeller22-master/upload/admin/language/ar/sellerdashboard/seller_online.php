<?php


// Heading
$_['heading_title'] = 'الباعة المتواجدون الآن';

// Text
$_['text_view'] = 'المزيد ...';
